from pymongo import MongoClient
from pymongo.errors import ServerSelectionTimeoutError

# specific timeout to fail fast if DB is not running
MONGO_TIMEOUT = 2000 # 2 seconds

try:
    client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=MONGO_TIMEOUT)
    db = client["healthtrack_db"]
    users_collection = db["users"]
    doctors_collection = db["doctors"]
    reports_collection = db["reports"]
    alerts_collection = db["alerts"]
    contact_collection = db["contact_messages"] # New collection for contact
except Exception as e:
    # Fallback to None if initialization fails completely (rare with pymongo lazy connect)
    client = None
    db = None
    users_collection = None
    doctors_collection = None
    reports_collection = None
    alerts_collection = None
    contact_collection = None

def is_db_connected():
    if not client:
        return False
    try:
        # The ismaster command is cheap and does not require auth.
        client.admin.command('ismaster')
        return True
    except ServerSelectionTimeoutError:
        return False
    except Exception:
        return False
