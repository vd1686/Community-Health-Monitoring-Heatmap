from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_exempt
import json
import hashlib
import datetime
from collections import Counter
from bson import ObjectId
from django.http import JsonResponse
from .forms import (
    UserSignupForm,
    UserProfileForm,
    DoctorSignupForm,
    DoctorProfileForm
)
from .mongo import (
    users_collection, doctors_collection, reports_collection, 
    alerts_collection, contact_collection, is_db_connected
)
from pymongo.errors import PyMongoError

@csrf_exempt
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')

    return render(request, "auth/login.html")

def logout_view(request):
    logout(request)
    return redirect('login')

def signup_user(request):
    if not is_db_connected():
        return render(request, "auth/signup_user.html", {"error": "Database service is offline. Please try again later."})
        
    if request.method == "POST":
        user_form = UserSignupForm(request.POST)
        profile_form = UserProfileForm(request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            user = User.objects.create_user(
                username=user_form.cleaned_data['username'],
                email=user_form.cleaned_data['email'],
                password=user_form.cleaned_data['password']
            )

            users_collection.insert_one({
                "django_user_id": user.id,
                "username": user.username,
                "email": user.email,
                "age": profile_form.cleaned_data['age'],
                "address": profile_form.cleaned_data['address'],
                "mobile": profile_form.cleaned_data['mobile'],
                "health_conditions": profile_form.cleaned_data['health_conditions'],
                "role": "user"
            })

            return render(request, "auth/signup_user.html", {"success": True})

    return render(request, "auth/signup_user.html")


def signup_doctor(request):
    if not is_db_connected():
        return render(request, "auth/signup_doctor.html", {"error": "Database service is offline. Please try again later."})
        
    if request.method == "POST":
        user_form = DoctorSignupForm(request.POST)
        profile_form = DoctorProfileForm(request.POST, request.FILES)

        if user_form.is_valid() and profile_form.is_valid():
            user = User.objects.create_user(
                username=user_form.cleaned_data['username'],
                email=user_form.cleaned_data['email'],
                password=user_form.cleaned_data['password']
            )

            doctor_profile = profile_form.save(commit=False)
            doctor_profile.user = user
            doctor_profile.save()

            doctors_collection.insert_one({
                "django_user_id": user.id,
                "username": user.username,
                "email": user.email,
                "age": doctor_profile.age,
                "address": doctor_profile.address,
                "mobile": doctor_profile.mobile,
                "specialization": doctor_profile.specialization,
                "document_path": doctor_profile.verification_document.url,
                "verified": False,
                "role": "doctor"
            })

            return render(request, "auth/signup_doctor.html", {"success": True})

    return render(request, "auth/signup_doctor.html")


@login_required(login_url='/')
def dashboard(request):
    user_id = request.user.id
    
    role = "Unknown"
    profile = {}
    display_id = "Guest"
    
    if is_db_connected():
        try:
            user_data = users_collection.find_one({"django_user_id": user_id})
            doctor_data = doctors_collection.find_one({"django_user_id": user_id})

            # Generate persistent Anonymous ID
            hash_object = hashlib.sha256(str(user_id).encode())
            short_hash = hash_object.hexdigest()[:8].upper()
            
            if user_data:
                role = "User"
                profile = user_data
                display_id = f"User-{short_hash}"
            elif doctor_data:
                role = "Doctor"
                profile = doctor_data
                display_id = f"Dr. {request.user.username}"
        except Exception:
            role = "Error"
    else:
         role = "Offline"

    # Check messages and appointments for doctor
    messages = []
    appointments = []
    if is_db_connected():
        try:
             # Fetch all contacts and categorize them
             all_contacts = list(contact_collection.find().sort("timestamp", -1).limit(50))
             for c in all_contacts:
                 c['id'] = str(c['_id']) # For JS access
                 if c.get('contact_type') == 'appointment':
                     appointments.append(c)
                 else:
                     messages.append(c)
        except: pass

    context = {
        "role": role,
        "profile": profile,
        "anonymous_id": display_id,
        "db_status": "connected" if role not in ["Offline", "Error"] else "disconnected",
        "messages": messages,
        "appointments": appointments
    }

    if role == "Doctor":
        return render(request, "doctor.html", context)
    else:
        return render(request, "dashboard.html", context)


# ---------------- API: SUBMIT REPORT ----------------
@csrf_exempt
def submit_report(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
             return JsonResponse({"status": "error", "message": "Unauthorized"}, status=401)

        try:
            data = json.loads(request.body)
            
            # Robust doctor check: verify if the user exists in doctors_collection
            user_id = request.user.id
            is_doctor_record = doctors_collection.find_one({"django_user_id": user_id}) or \
                               doctors_collection.find_one({"django_user_id": str(user_id)})
            
            # Additional check: ensure the user actually has the doctor role if found
            if is_doctor_record and is_doctor_record.get('role') == 'doctor':
                display_name = f"Dr. {request.user.username}"
                role = "doctor"
                is_anonymous = False
            else:
                # Normal user: generate anonymous ID
                hash_object = hashlib.sha256(str(user_id).encode())
                short_hash = hash_object.hexdigest()[:8].upper()
                display_name = f"User-{short_hash}"
                role = "user"
                is_anonymous = True

            report = {
                "user_id": user_id, 
                "display_name": display_name,
                "role": role,
                "is_anonymous": is_anonymous,
                
                "lat": float(data.get('lat')),
                "lng": float(data.get('lng')),
                
                "symptoms": data.get('symptoms', []), 
                "history": data.get('history', ""),   
                "severity": int(data.get('severity', 1)),
                "age": data.get('age', 0), 
                "gender": data.get('gender', "Not Specified"),
                "replies": [],
                
                "timestamp": datetime.datetime.now()
            }
            
            reports_collection.insert_one(report)
            
            return JsonResponse({
                "status": "success", 
                "message": "Report saved!", 
                "display_name": display_name 
            })
            
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
            
    return JsonResponse({"status": "error", "message": "Invalid method"}, status=405)


# ---------------- API: SUBMIT REPLY ----------------
# ---------------- API: SUBMIT REPLY ----------------
@csrf_exempt
def submit_reply(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
             return JsonResponse({"status": "error", "message": "Unauthorized"}, status=401)

        try:
            data = json.loads(request.body)
            report_id = data.get('report_id')
            message = data.get('message')
            
            if not report_id or not message:
                return JsonResponse({"status": "error", "message": "Missing data"}, status=400)

            # Verify Doctor
            user_id = request.user.id
            # Try both int and str to be extremely safe with MongoDB lookups
            doctor = doctors_collection.find_one({"django_user_id": user_id}) or \
                     doctors_collection.find_one({"django_user_id": str(user_id)})
            
            if not doctor:
                 print(f"DEBUG: Doctor check failed for user {user_id}") # Log to console
                 return JsonResponse({"status": "error", "message": "Only doctors can reply"}, status=403)

            reply = {
                "doctor_name": f"Dr. {request.user.username}",
                "message": message,
                "timestamp": datetime.datetime.now()
            }
            
            # Ensure report_id is a valid ObjectId
            try:
                oid = ObjectId(report_id)
            except:
                return JsonResponse({"status": "error", "message": "Invalid Report ID format"}, status=400)

            result = reports_collection.update_one(
                {"_id": oid},
                {"$push": {"replies": reply}}
            )
            
            if result.modified_count > 0:
                print(f"Reply added to {report_id} by {request.user.username}")
                return JsonResponse({"status": "success", "message": "Reply sent!"})
            else:
                print(f"Report {report_id} not found during reply")
                return JsonResponse({"status": "error", "message": "Report not found"}, status=404)

        except Exception as e:
            print(f"Error in submit_reply: {e}")
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid method"}, status=405)


# ---------------- API: BROADCAST ALERT ----------------
from .mongo import alerts_collection

@csrf_exempt
def send_broadcast(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
             return JsonResponse({"status": "error", "message": "Unauthorized"}, status=401)

        try:
            data = json.loads(request.body)
            message = data.get('message')
            level = data.get('level', 'info') # info, warning, critical
            lat = data.get('lat')
            lng = data.get('lng')

            if not message:
                return JsonResponse({"status": "error", "message": "Missing message"}, status=400)
            
            # Verify Doctor
            user_id = request.user.id
            doctor = doctors_collection.find_one({"django_user_id": user_id}) or \
                     doctors_collection.find_one({"django_user_id": str(user_id)})
            if not doctor:
                 return JsonResponse({"status": "error", "message": "Only doctors can broadcast"}, status=403)

            alert = {
                "doctor_name": f"Dr. {request.user.username}",
                "message": message,
                "level": level,
                "lat": float(lat) if lat else None,
                "lng": float(lng) if lng else None,
                "timestamp": datetime.datetime.now()
            }
            
            alerts_collection.insert_one(alert)
            return JsonResponse({"status": "success", "message": "Broadcast sent!"})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid method"}, status=405)


# ---------------- API: GET BROADCASTS ----------------
def get_broadcasts(request):
    if not is_db_connected():
        return JsonResponse({"alerts": []})

    try:
        # Get last 5 active alerts
        alerts_cursor = alerts_collection.find().sort("timestamp", -1).limit(5)
        alerts = []
        for a in alerts_cursor:
            alerts.append({
                "message": a.get("message"),
                "level": a.get("level"),
                "timestamp": a.get("timestamp")
            })
        return JsonResponse({"alerts": alerts})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


@csrf_exempt
def submit_contact(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
             return JsonResponse({"status": "error", "message": "Unauthorized"}, status=401)
             
        if not is_db_connected():
             return JsonResponse({"status": "error", "message": "Service unavailable"}, status=503)

        try:
            data = json.loads(request.body)
            msg = data.get('message')
            doctor_id = data.get('doctor_id')
            contact_type = data.get('contact_type', 'message')  # 'message', 'call', 'appointment'
            
            if not msg: return JsonResponse({"status": "error", "message": "Missing message"}, status=400)
            
            contact_record = {
                "user_id": request.user.id,
                "username": request.user.username,
                "doctor_id": doctor_id,
                "contact_type": contact_type,
                "message": msg,
                "timestamp": datetime.datetime.now(),
                "read": False,
                "status": "pending" if contact_type == "appointment" else "none"
            }

            if contact_type == "appointment":
                contact_record["appointment_date"] = data.get('appointment_date')
                contact_record["appointment_time"] = data.get('appointment_time')

            contact_collection.insert_one(contact_record)
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
            
    return JsonResponse({"status": "error"}, status=405)



@csrf_exempt
def update_appointment_status(request):
    if request.method == "POST":
        if not request.user.is_authenticated:
            return JsonResponse({"status": "error", "message": "Unauthorized"}, status=401)
            
        try:
            data = json.loads(request.body)
            contact_id = data.get('contact_id')
            new_status = data.get('status') # approved, rejected, etc.
            doctor_note = data.get('note', '')

            # Verify if user is a doctor
            user_id = request.user.id
            is_doctor = doctors_collection.find_one({"django_user_id": user_id}) or \
                        doctors_collection.find_one({"django_user_id": str(user_id)})
            
            if not is_doctor:
                return JsonResponse({"status": "error", "message": "Permission denied"}, status=403)

            from bson import ObjectId
            contact_collection.update_one(
                {"_id": ObjectId(contact_id)},
                {"$set": {"status": new_status, "doctor_note": doctor_note}}
            )
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
    return JsonResponse({"status": "error"}, status=405)


# ---------------- API: GET REPORTS ----------------
def get_reports(request):
    if not is_db_connected():
        return JsonResponse({"points": [], "stats": {"top_symptoms": [], "top_counts": []}})

    try:
        reports_cursor = reports_collection.find().sort("timestamp", -1).limit(100)
        
        data = []
        symptoms_list = []
        
        for r in reports_cursor:
            time_diff = datetime.datetime.now() - r['timestamp']
            minutes = divmod(time_diff.total_seconds(), 60)[0]
            if minutes < 60:
                time_str = f"{int(minutes)}m ago"
            else:
                time_str = f"{int(minutes/60)}h ago"
            
            if 'symptoms' in r and isinstance(r['symptoms'], list):
                symptoms_list.extend(r['symptoms'])
            elif 'symptoms' in r and isinstance(r['symptoms'], str):
                 symptoms_list.append(r['symptoms'])
            
            # Format replies
            formatted_replies = []
            if 'replies' in r:
                for rep in r['replies']:
                    formatted_replies.append({
                        "doctor": rep.get('doctor_name'),
                        "message": rep.get('message')
                    })

            data.append({
                "lat": r.get('lat'),
                "lng": r.get('lng'),
                "intensity": r.get('severity', 1) / 5.0, 
                
                "id": str(r.get('_id')),
                "display_name": r.get('display_name', 'Anonymous'),
                "symptoms": r.get('symptoms', []),
                "history": r.get('history', ""),
                "replies": formatted_replies,
                "severity_label": "High" if r.get('severity', 1) >= 4 else ("Moderate" if r.get('severity', 1) >= 3 else "Low"),
                "severity_val": r.get('severity', 1),
                "age": r.get('age'),
                "gender": r.get('gender', 'Not Specified'),
                "time": time_str
            })
            
        symptom_counts = Counter(symptoms_list)
        top_symptoms = symptom_counts.most_common(5)
        
        return JsonResponse({
            "points": data,
            "stats": {
                "top_symptoms": [s[0] for s in top_symptoms],
                "top_counts": [s[1] for s in top_symptoms]
            }
        })
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


# ---------------- API: GET DOCTORS ----------------
def get_doctors(request):
    if not is_db_connected():
        return JsonResponse({"doctors": []})

    try:
        doctors_cursor = doctors_collection.find({"verified": True})
        doctors = []
        for d in doctors_cursor:
            doctors.append({
                "id": str(d.get("_id")),
                "name": f"Dr. {d.get('username')}",
                "specialization": d.get('specialization', 'General Physician'),
                "mobile": d.get('mobile', '')
            })
        
        # If no verified doctors, return all doctors for demo purposes
        if not doctors:
            doctors_cursor = doctors_collection.find()
            for d in doctors_cursor:
                doctors.append({
                    "id": str(d.get("_id")),
                    "name": f"Dr. {d.get('username')}",
                    "specialization": d.get('specialization', 'General Physician'),
                    "mobile": d.get('mobile', '')
                })
        
        return JsonResponse({"doctors": doctors})
    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)
