from django.db import models

# Create your models here.
from django.contrib.auth.models import User
from django.db import models

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    age = models.IntegerField()
    address = models.TextField()
    mobile = models.CharField(max_length=15)
    health_conditions = models.TextField(blank=True)

    def __str__(self):
        return self.user.username


class DoctorProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    age = models.IntegerField()
    address = models.TextField()
    mobile = models.CharField(max_length=15)
    specialization = models.CharField(max_length=100)
    verification_document = models.ImageField(upload_to="doctor_docs/")
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"Dr. {self.user.username}"
