from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup/user/', views.signup_user, name='signup_user'),
    path('signup/doctor/', views.signup_doctor, name='signup_doctor'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('submit_report/', views.submit_report, name='submit_report'),
    path('submit_reply/', views.submit_reply, name='submit_reply'),
    path('get_reports/', views.get_reports, name='get_reports'),
    path('send_broadcast/', views.send_broadcast, name='send_broadcast'),
    path('get_broadcasts/', views.get_broadcasts, name='get_broadcasts'),
    path('submit_contact/', views.submit_contact, name='submit_contact'),
    path('get_doctors/', views.get_doctors, name='get_doctors'),
    path('update_appointment_status/', views.update_appointment_status, name='update_appointment_status'),
]
