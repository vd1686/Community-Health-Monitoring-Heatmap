import pymongo
import random
import datetime
from bson.objectid import ObjectId

# Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["healthtrack_db"]
reports_collection = db["reports"]

# Centers for mock data (London Default)
CENTERS = [
    {"lat": 51.505, "lng": -0.09, "name": "London"},
]

SYMPTOMS = [
    "Fever", "Cough", "Headache", "Sore Throat", "Fatigue", 
    "Shortness of Breath", "Nausea", "Body Aches", "Chills", "Running Nose"
]

GENDERS = ["Male", "Female", "Other"]

def generate_reports(n=50):
    reports = []
    print(f"Generating {n} reports...")
    
    for _ in range(n):
        center = random.choice(CENTERS)
        
        # Random spread ~ 0.15 degrees (approx 15km) for wider scatter
        lat = center["lat"] + random.uniform(-0.15, 0.15)
        lng = center["lng"] + random.uniform(-0.15, 0.15)
        
        severity = random.randint(1, 5)
        
        # Weighted symptoms based on severity
        num_symptoms = random.randint(1, 3)
        if severity >= 4:
            report_symptoms = random.sample(SYMPTOMS[:5], num_symptoms) # More "serious" flu-like stats top of list
        else:
            report_symptoms = random.sample(SYMPTOMS, num_symptoms)
            
        is_anon = True
        gender = random.choice(GENDERS)
        age = random.randint(18, 80)
        
        # Generated Time (last 24 hours)
        minutes_ago = random.randint(0, 1440) 
        timestamp = datetime.datetime.now() - datetime.timedelta(minutes=minutes_ago)
        
        report = {
            "user_id": None, 
            "display_name": f"User-{random.randint(1000,9999)}",
            "role": "user",
            "is_anonymous": True,
            
            "lat": lat,
            "lng": lng,
            
            "symptoms": report_symptoms, 
            "history": "None" if random.random() > 0.3 else "Asthma",   
            "severity": severity,
            "age": age,
            "gender": gender,
            "replies": [],
            
            "timestamp": timestamp
        }
        reports.append(report)

    reports_collection.insert_many(reports)
    print("Done! Inserted", len(reports), "records.")

if __name__ == "__main__":
    generate_reports(50)
