import os
import django
import json
from datetime import datetime
from bson import ObjectId

# Setup Django Environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproject.settings')
django.setup()

from django.contrib.auth.models import User
from myapp.models import UserProfile, DoctorProfile
from myapp.mongo import (
    users_collection, doctors_collection, reports_collection, 
    alerts_collection, contact_collection, is_db_connected
)

def format_mongo_doc(doc):
    if not doc: return "None"
    
    def serialize(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, ObjectId):
            return str(obj)
        if isinstance(obj, list):
            return [serialize(i) for i in obj]
        if isinstance(obj, dict):
            return {k: serialize(v) for k, v in obj.items()}
        return obj

    clean_doc = serialize(doc)
    return json.dumps(clean_doc, indent=2)

def view_sqlite():
    print("\n" + "="*50)
    print("--- SQLITE DATABASE (Django Auth & Profiles) ---")
    print("="*50)
    
    print("\n[TABLE: auth_user]")
    users = User.objects.all()
    print(f"Total Records: {users.count()}")
    for user in users:
        print(f"ID: {user.id} | Username: {user.username} | Email: {user.email} | Staff: {user.is_staff}")

    print("\n[TABLE: myapp_doctorprofile]")
    docs = DoctorProfile.objects.all()
    print(f"Total Records: {docs.count()}")
    for d in docs:
        print(f"User: {d.user.username} | Specialization: {d.specialization} | Verified: {d.is_verified}")

    print("\n[TABLE: myapp_userprofile]")
    profiles = UserProfile.objects.all()
    print(f"Total Records: {profiles.count()}")
    for p in profiles:
        print(f"User: {p.user.username} | Mobile: {p.mobile} | Age: {p.age}")

def view_mongo():
    print("\n" + "="*50)
    print("--- MONGODB DATABASE (Reports & App Data) ---")
    print("="*50)
    
    if not is_db_connected():
        print("ERROR: Could not connect to MongoDB. Is it running?")
        return

    # Check Reports
    print("\n[COLLECTION: reports]")
    count = reports_collection.count_documents({})
    print(f"Total Records: {count}")
    for r in reports_collection.find().sort("timestamp", -1).limit(3):
        print(format_mongo_doc(r))
        print("-" * 20)

    # Check Users (Mongo side)
    print("\n[COLLECTION: users]")
    count = users_collection.count_documents({})
    print(f"Total Records: {count}")
    for u in users_collection.find().limit(3):
        print(format_mongo_doc(u))
        print("-" * 20)

    # Check Alerts
    print("\n[COLLECTION: alerts]")
    count = alerts_collection.count_documents({})
    print(f"Total Records: {count}")
    for a in alerts_collection.find().limit(3):
        print(format_mongo_doc(a))
        print("-" * 20)

if __name__ == "__main__":
    view_sqlite()
    view_mongo()
