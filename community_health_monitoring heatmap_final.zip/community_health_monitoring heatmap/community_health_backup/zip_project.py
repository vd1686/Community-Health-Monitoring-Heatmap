import os
import zipfile

def zip_project(root_dir, output_filename):
    exclude_dirs = {'venv', '__pycache__', '.git', '.gemini'}
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file == output_filename:
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, root_dir)
                zipf.write(file_path, arcname)
    print(f"Successfully created {output_filename}")

if __name__ == "__main__":
    project_root = r"c:\Users\admin\Documents\community_health"
    output_zip = os.path.join(project_root, "community_health_backup.zip")
    zip_project(project_root, output_zip)
